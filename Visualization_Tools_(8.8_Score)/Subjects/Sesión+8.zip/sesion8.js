console.log ("Hola desde el grafo")
d3.json("https://gist.githubusercontent.com/mbostock/4062045/raw/5916d145c8c048a6e3086915a6be464467391c62/miserables.json").then (function(data){
   console.log ("Ya hemos recibido los datos")
    
    // ESCALA COLORES
    var escalaColor=d3.scaleOrdinal(d3.schemeCategory10)
    
    
    // 4. LAYOUTS
    
    // Fuerza 1. TODO DEBE QUEDAR EN EL CENTRO
    // Fuerza 2. LOS ELEMENTOS RELACIONADOS TIENEN QUE ESTAR CERCA
    // Fuerza 3. NO PUEDEN ESTAR TAN CERCA COMO PARA QUE SE SOLAPEN
    // Fuerza 4. LOS NODOS SE REPELEN ENTRE SI
    // Fuerza 5. Enlaces. LOS ELEMENTOS QUE ESTAN CONECTADOS CON LINKS, TIRAN MAS UNOS DE OTROS
    
    var layout = d3.forceSimulation()
        .force ("link", d3.forceLink().id(d=>d.id))
        .force ("charge", d3.forceManyBody())
        .force ("center", d3.forceCenter(250,250))
    
    layout
        .nodes(data.nodes)
    
        .on("tick",onTick)

    layout  
        .force("link")
        .links(data.links)
    
    // 1. CREAR SVG
    var svg = d3.select ("body")
        .append("svg")
        .attr("width", 500)
        .attr("height",500)
    
    // 2. CREAMOS LINEAS Y DESPUES LOS NODOS
    var links = svg
        // CAPA PARA LOS ENLACES
        .append ("g")
        .selectAll("line")
        // Cruzamos con los datos de los enlaces
        .data(data.links)
        .enter()
        .append("line")
    
        //.style("stroke", "#aaa")
        .attr("stroke-width", d=>d.value/5)
    
        .style ("stroke", d =>{
          if (d.source.group == d.target.group)
              return (escalaColor (d.source.group))
          else
              return ("#aaa")
            
            
            
        })
    
    
    // 3. CREAMOS LOS NODOS (CIRCULOS)
    var nodes = svg
        // CAPA PARA LOS NODOS
        .append ("g")
        .selectAll("circle")
        // Cruzamos con los datos de los nodos
        .data(data.nodes)
        .enter()
        .append("circle")
        .attr("r",5)
        //.attr("fill",blue)
        .attr("fill", d=>escalaColor(d.group))
                  
                  

    // 6 FUNCTION ONTICK
    function onTick(){
        nodes
            .attr("cx", d => d.x)
            .attr("cy", d => d.y)
        links   
            .attr("x1", d => d.source.x)
        .attr("x2", d => d.target.x)
        .attr("y1", d => d.source.y)
        .attr("y2", d => d.target.y)
        
        
    }
                  
                  
                  
})