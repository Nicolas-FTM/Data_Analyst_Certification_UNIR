/*******************************************************************************************************/
/* Fichero encargado principalmente de la visualización del gráfico en D3                              */
/*******************************************************************************************************/

// https://observablehq.com/@d3/zoomable-sunburst@357

// Declaramos variables para facilitar la interacción a través de dicha variable

var archivoJson = "./2020.json"

// Creamos varios eventos listener que esperan a un evento para generar el cambio de representación en función de un archivo json distinto
// Año 2020
const myLink2020 = document.getElementById("2020");
myLink2020.addEventListener("click", function() {
    archivoJson = "./2020.json";
    _datosURLString(archivoJson);   // Llamamos a una función para cargar el json en la función de la gráfica

        var svg = d3.select("body").selectAll("svg").data(archivoJson)
        svg.enter().append("svg")
});

// Año 2021
const myLink2021 = document.getElementById("2021");
myLink2021.addEventListener("click", function() {
    archivoJson = "./2021.json";
    _datosURLString(archivoJson);
        var svg = d3.select("body").selectAll("svg").data(archivoJson)
        svg.enter().append("svg")
});    

// Año 2022
const myLink2022 = document.getElementById("2022");
myLink2022.addEventListener("click", function() {
    archivoJson = "./2022.json";
    _datosURLString(archivoJson);
        var svg = d3.select("body").selectAll("svg").data(archivoJson)
        svg.enter().append("svg")
});

// Creamos una función para imprimir en MarkDown el titulo de la página y el comentario en JavaScript
function _1(md){return(
md`# Diagrama Sunburst con opción a hacer zoom

Este diagrama es una variante del diagrama [sunburst diagram](/@d3/sunburst). Dicho gráfico muestra en que se gastan el dinero los ciudadanos según datos estadísticos al mes.`
)}

// Método constructor de la gráfica
// La funcion _chart obtiene por argumentos el nombre de las funciones (Esto es debido a las main.variables que se definen a posteriori) y 
// realiza las funciones en base a los datos
function _chart(partition,data,d3,width,color,arc,format,radius)
{
  // Obtiene una variable Json que me separa los datos en categorías
  const root = partition(data);
  root.each(d => d.current = d);

  // Creamos el objeto svg
  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, width])
      .style("font", "6px sans-serif");

  // Alteramos el objeto svg para que realice una transformación de tipo traslación
  const g = svg.append("g")
      .attr("transform", `translate(${width / 2},${width / 2})`);

  // Creamos los slices por los cuales se va a dividir cada sector del gráfico
  const path = g.append("g")
    .selectAll("path")
    .data(root.descendants().slice(1))
    .join("path")
      .attr("fill", d => { while (d.depth > 1) d = d.parent; return color(d.data.name); })
      .attr("fill-opacity", d => arcVisible(d.current) ? (d.children ? 0.6 : 0.4) : 0)
      .attr("pointer-events", d => arcVisible(d.current) ? "auto" : "none")

      .attr("d", d => arc(d.current));

  // Filtramos por los slices mencionados anteriormente (json asociados a otros json = children)
  path.filter(d => d.children)
      .style("cursor", "pointer")
      .on("click", clicked);
  path.append("title")
      .text(d => `${d.ancestors().map(d => d.data.name).reverse().join("/")}\n${format(d.value)}`);

  // Creamos las etiquetas de cada sector y de cada slice
  const label = g.append("g")
      .attr("pointer-events", "none")
      .attr("text-anchor", "middle")
      .style("user-select", "none")
    .selectAll("text")
    .data(root.descendants().slice(1))
    .join("text")
      .attr("dy", "0.35em")
      .attr("fill-opacity", d => +labelVisible(d.current))
      .attr("transform", d => labelTransform(d.current))
      .text(d => d.data.name);

  // Creamos el propio gráfico
  const parent = g.append("circle")
      .datum(root)
      .attr("r", radius)
      .attr("fill", "none")
      .attr("pointer-events", "all")
      .on("click", clicked);

  // Función que cada vez que cliquemos cambia el dato
  function clicked(event, p) {
    parent.datum(p.parent || root);

    root.each(d => d.target = {
      x0: Math.max(0, Math.min(1, (d.x0 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI,
      x1: Math.max(0, Math.min(1, (d.x1 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI,
      y0: Math.max(0, d.y0 - p.depth),
      y1: Math.max(0, d.y1 - p.depth)
    });

    const t = g.transition().duration(750);

    // Incorporamos animaciones

    // Transition the data on all arcs, even the ones that aren’t visible,
    // so that if this transition is interrupted, entering arcs will start
    // the next transition from the desired position.
    path.transition(t)
        .tween("data", d => {
          const i = d3.interpolate(d.current, d.target);
          return t => d.current = i(t);
        })
      .filter(function(d) {
        return +this.getAttribute("fill-opacity") || arcVisible(d.target);
      })
        .attr("fill-opacity", d => arcVisible(d.target) ? (d.children ? 0.6 : 0.4) : 0)
        .attr("pointer-events", d => arcVisible(d.target) ? "auto" : "none") 

        .attrTween("d", d => () => arc(d.current));

    label.filter(function(d) {
        return +this.getAttribute("fill-opacity") || labelVisible(d.target);
      }).transition(t)
        .attr("fill-opacity", d => +labelVisible(d.target))
        .attrTween("transform", d => () => labelTransform(d.current));
  }
  
  // Hacemos los arcos visibles
  function arcVisible(d) {
    return d.y1 <= 3 && d.y0 >= 1 && d.x1 > d.x0;
  }
 
  // Hacemos las etiquetas visibles
  function labelVisible(d) {
    return d.y1 <= 3 && d.y0 >= 1 && (d.y1 - d.y0) * (d.x1 - d.x0) > 0.03;
  }

  // Hacemos que las etiquetas se roten
  function labelTransform(d) {
    const x = (d.x0 + d.x1) / 2 * 180 / Math.PI;
    const y = (d.y0 + d.y1) / 2 * radius;
    return `rotate(${x - 90}) translate(${y},0) rotate(${x < 180 ? 0 : 180})`;
  }

  return svg.node();
}

// Se define el origen de los datos
function _data(FileAttachment){return(
FileAttachment("flare-2.json").json()
)}

// Funcion que define las particiones
function _partition(d3){return(
data => {
  const root = d3.hierarchy(data)
      .sum(d => d.value)
      .sort((a, b) => b.value - a.value);
  return d3.partition()
      .size([2 * Math.PI, root.height + 1])
    (root);
}
)}

// Funcion que colorea los sectores
function _color(d3,data){return(
d3.scaleOrdinal(d3.quantize(d3.interpolateRainbow, data.children.length + 1))
)}

// Funcion que pone formato a los numeros
function _format(d3){return(
d3.format(",d")
)}

// Constante que definimos para el ancho
function _width(){return(
932
)}

// Constante que definimos en base al ancho
function _radius(width){return(
width / 6
)}

// Definimos los sectores en base a los radios
function _arc(d3,radius){return(
d3.arc()
    .startAngle(d => d.x0)
    .endAngle(d => d.x1)
    .padAngle(d => Math.min((d.x1 - d.x0) / 2, 0.005))
    .padRadius(radius * 1.5)
    .innerRadius(d => d.y0 * radius)
    .outerRadius(d => Math.max(d.y0 * radius, d.y1 * radius - 1))
)}

// Introducimos la función para a raíz de los eventos modificar el objeto del gráfico
function _datosURLString(options){
    if(typeof options === "undefined"){
        archivoJson = "./2022.json";
        console.log("Este es al inicio: ");
        console.log(archivoJson);
        
    }
    else{
        archivoJson = options;
        console.log("Esto llega a ejecutarse: ");
        console.log(archivoJson);
        
    }
    return(archivoJson)
}

// Función de carga de la gráfica
export default function define(runtime, observer) {

  // Creamos la variable que será el hilo de la ejecución
  const main = runtime.module();
  function toString() { return this.url; }

  // Creamos un nuevo Mapa/Diccionario para los años
  const fileAttachments = new Map([
    ["flare-2.json", {
        url: new URL(_datosURLString(), import.meta.url), 
        mimeType: "application/json", 
        toString}]
  ]);

  // Creamos las variable y las funciones que usaremos en la ejecución de la página
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("chart")).define("chart", ["partition","data","d3","width","color","arc","format","radius"], _chart);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer("partition")).define("partition", ["d3"], _partition);
  main.variable(observer("color")).define("color", ["d3","data"], _color);
  main.variable(observer("format")).define("format", ["d3"], _format);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("radius")).define("radius", ["width"], _radius);
  main.variable(observer("arc")).define("arc", ["d3","radius"], _arc);
  return main;
}
