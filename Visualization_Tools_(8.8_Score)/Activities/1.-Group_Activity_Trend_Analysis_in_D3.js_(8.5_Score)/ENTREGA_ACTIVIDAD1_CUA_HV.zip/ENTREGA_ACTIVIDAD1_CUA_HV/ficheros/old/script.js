// Seleccionar los contenedores de las gráficas
const contenedor1 = d3.select("#contenedor-1");
const contenedor2 = d3.select("#contenedor-2");
const contenedor3 = d3.select("#contenedor-3");
const contenedor4 = d3.select("#contenedor-4");

// Leer el archivo CSV y procesar los datos
d3.csv("datos.csv").then(function(datos) {
  
  // Convertir los valores a números
  datos.forEach(function(d) {
    d.Valor1 = +d.Valor1;
    d.Valor2 = +d.Valor2;
    d.Valor3 = +d.Valor3;
  });
  
  // Crear escalas para los ejes x e y
  const x = d3.scaleBand()
    .domain(datos.map(d => d.Categoria))
    .range([0, contenedor1.node().clientWidth])
    .padding(0.1);
  
  const y = d3.scaleLinear()
    .domain([0, d3.max(datos, d => d3.max([d.Valor1, d.Valor2, d.Valor3]))])
    .nice()
    .range([contenedor1.node().clientHeight, 0]);
  
  // Crear la primera gráfica de barras
  const grafica1 = contenedor1.append("svg")
    .attr("width", contenedor1.node().clientWidth)
    .attr("height", contenedor1.node().clientHeight);
  
  grafica1.selectAll("rect")
    .data(datos)
    .join("rect")
    .attr("x", d => x(d.Categoria))
    .attr("y", d => y(d.Valor1))
    .attr("width", x.bandwidth())
    .attr("height", d => contenedor1.node().clientHeight - y(d.Valor1)); 

  const grafica2 = contenedor2.append("svg")
    .attr("width", contenedor2.node().clientWidth)
    .attr("height", contenedor2.node().clientHeight);
  
  grafica2.selectAll("rect")
    .data(datos)
    .join("rect")
    .attr("x", d => x(d.Categoria))
    .attr("y", d => y(d.Valor1))
    .attr("width", x.bandwidth())
    .attr("height", d => contenedor2.node().clientHeight - y(d.Valor1)); 


  const grafica3 = contenedor3.append("svg")
    .attr("width", contenedor3.node().clientWidth)
    .attr("height", contenedor3.node().clientHeight);
  
  grafica3.selectAll("rect")
    .data(datos)
    .join("rect")
    .attr("x", d => x(d.Categoria))
    .attr("y", d => y(d.Valor1))
    .attr("width", x.bandwidth())
    .attr("height", d => contenedor3.node().clientHeight - y(d.Valor1)); 

  const grafica4 = contenedor4.append("svg")
    .attr("width", contenedor4.node().clientWidth)
    .attr("height", contenedor4.node().clientHeight);
  
  grafica4.selectAll("rect")
    .data(datos)
    .join("rect")
    .attr("x", d => x(d.Categoria))
    .attr("y", d => y(d.Valor1))
    .attr("width", x.bandwidth())
    .attr("height", d => contenedor4.node().clientHeight - y(d.Valor1)); 

})
