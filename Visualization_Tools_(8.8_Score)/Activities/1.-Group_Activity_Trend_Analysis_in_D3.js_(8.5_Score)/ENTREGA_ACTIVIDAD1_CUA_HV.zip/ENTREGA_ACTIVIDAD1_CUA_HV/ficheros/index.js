// Exportamos la función del fichero main.js
export {default} from "./main.js";
